package com.cg.employee.entity;

public class Employee {

	private String empId;
	private String empName;
	private double empSalary;
	private String empBU;
	private int empAge;

	public Employee(String empId, String empName, double empSalary, String empBU, int empAge) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empBU = empBU;
		this.empAge = empAge;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public String getEmpBU() {
		return empBU;
	}

	public void setEmpBU(String empBU) {
		this.empBU = empBU;
	}

	public int getEmpAge() {
		return empAge;
	}

	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empBU=" + empBU
				+ ", empAge=" + empAge + "]";
	}

}
