/**
 * 
 */
package com.cg.employee.entity;

public class SBU {

	private String sbuId;
	private String sbuName;
	private double sbuHead;

	public String getSbuId() {
		return sbuId;
	}

	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}

	public SBU(String sbuId, String sbuName, double sbuHead) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
	}

	@Override
	public String toString() {
		return "SBU [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + "]";
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public double getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(double sbuHead) {
		this.sbuHead = sbuHead;
	}

}
