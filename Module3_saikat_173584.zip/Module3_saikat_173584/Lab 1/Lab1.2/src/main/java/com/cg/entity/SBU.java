

package com.cg.entity;


public class SBU {

	private String sbuId;
	private String sbuName;
	private String sbuHead;

	
	public String getSbuId() {
		return sbuId;
	}

	
	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}

	
	public SBU(String sbuId, String sbuName, String sbuHead) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
	}

	
	@Override
	public String toString() {
		return "SBU [sbuId:" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + "]";
	}

	
	public String getSbuName() {
		return sbuName;
	}

	public SBU() {
		// TODO Auto-generated constructor stub
	}
	 
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	
	public String getSbuHead() {
		return sbuHead;
	}

	
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

}
