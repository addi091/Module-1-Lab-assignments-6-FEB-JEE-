
package com.cg.entity;

public class Employee {

	private String empId;
	private String empName;
	private double empSalary;
	
	private int empAge;
	private SBU BU;
	
	public Employee() {
		
	}
	
	public String getEmpId() {
		return empId;
	}
	
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	
	public String getEmpName() {
		return empName;
	}
	
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	public double getEmpSalary() {
		return empSalary;
	}
	
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	
	public int getEmpAge() {
		return empAge;
	}
	
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}
	
	public SBU getBU() {
		return BU;
	}
	
	public void setBU(SBU bU) {
		BU = bU;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empAge=" + empAge
				+ ", BU=" + BU + "]";
	}
	
	public Employee(String empId, String empName, double empSalary, int empAge, SBU bU) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empAge = empAge;
		this.BU = bU;
	}
	

}