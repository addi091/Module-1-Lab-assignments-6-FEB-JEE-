/**
 * 
 */
package com.cg;


public class Employee {
	
	private int empId;
	private String empName;
	private double empSalary;
	private String empBU;
	private int empAge;
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empBU=" + empBU
				+ ", empAge=" + empAge + "]";
	}
	
	public Employee(int empId, String empName, double empSalary, String empBU, int empAge) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empBU = empBU;
		this.empAge = empAge;
	}
	
	public int getEmpId() {
		return empId;
	}
	
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	public String getEmpName() {
		return empName;
	}
	
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	public double getEmpSalary() {
		return empSalary;
	}
	
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	
	public String getEmpBU() {
		return empBU;
	}
	
	public void setEmpBU(String empBU) {
		this.empBU = empBU;
	}
	
	public int getEmpAge() {
		return empAge;
	}
	
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}


}
