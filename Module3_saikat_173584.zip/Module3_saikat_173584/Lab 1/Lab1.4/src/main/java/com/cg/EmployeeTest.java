/**
 * 
 */
package com.cg;

import static org.junit.Assert.assertNotNull;

import java.util.Scanner;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class EmployeeTest {

	@Test
	public void Test() {
		ApplicationContext emp = new ClassPathXmlApplicationContext("emp.xml");
		Employee e = (Employee) emp.getBean(Employee.class);
		
		System.out.println("Enter Employee ID");
		Scanner sc=new Scanner(System.in);
		int empId=sc.nextInt();
		if(empId==e.getEmpId()) {
		
		System.out.println(e);}
		else {
			System.out.println("Id not found");
		}
		
		assertNotNull(e);
	}

}
