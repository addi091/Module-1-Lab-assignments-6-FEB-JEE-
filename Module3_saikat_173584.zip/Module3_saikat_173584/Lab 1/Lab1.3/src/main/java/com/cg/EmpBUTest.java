
package com.cg;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;




public class EmpBUTest {
	@Test
	public void Test() {
		ApplicationContext emp = new ClassPathXmlApplicationContext("emp.xml");
		Employee e = (Employee) emp.getBean(Employee.class);
		SBU s=(SBU)emp.getBean(SBU.class);
		System.out.println("Employee details:");
		System.out.println(e);
		System.out.println(s);
		assertNotNull(e);
	}

}
