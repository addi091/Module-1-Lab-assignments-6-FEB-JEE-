
package com.cg;

import java.util.List;


public class SBU {
	private int sbuCode;
	private String sbuName;
	private String sbuHead;
	private List<Employee> emplist;
	Employee employee;

	
	public SBU() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public SBU(int sbuCode, String sbuName, String sbuHead, List<Employee> emplist) {
		super();
		this.sbuCode = sbuCode;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
		this.emplist = emplist;
	}

	
	@Override
	public String toString() {
		return "SBU [sbuCode=" + sbuCode + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + ", emplist=" + emplist
				+ "]";
	}

	
	public int getSbuCode() {
		return sbuCode;
	}

	
	public void setSbuCode(int sbuCode) {
		this.sbuCode = sbuCode;
	}

	
	public String getSbuName() {
		return sbuName;
	}

	
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	
	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

	
	public List<Employee> getEmplist() {
		return emplist;
	}

	
	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}

}
