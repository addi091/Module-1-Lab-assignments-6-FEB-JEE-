package com.cg.entity;

/**
 * @saikat
 */
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Product {

	@Id
	@Column(name = "id")
	@GeneratedValue
	private int Prodid;

	@Override
	public String toString() {
		return "Product [Prodid=" + Prodid + ", ProdName=" + ProdName + ", Prodprice=" + Prodprice + "]";
	}

	public int getProdid() {
		return Prodid;
	}

	public void setProdid(int prodid) {
		Prodid = prodid;
	}

	public String getProdName() {
		return ProdName;
	}

	public void setProdName(String prodName) {
		ProdName = prodName;
	}

	public double getProdprice() {
		return Prodprice;
	}

	public void setProdprice(double prodprice) {
		Prodprice = prodprice;
	}

	@Column(length = 20)
	private String ProdName;

	private double Prodprice;

}
