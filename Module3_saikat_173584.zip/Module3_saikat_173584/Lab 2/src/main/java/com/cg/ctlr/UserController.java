package com.cg.ctlr;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.TraineeInterface;

@Scope("session")
@Controller
public class UserController {
	ArrayList<String> domainList;
	ArrayList<String> locationList;
	
	
	// injecting service
	@Autowired
	private TraineeInterface service;

	
	//login page  
	@RequestMapping("/checkLogin")
	public String checkLogin(Login login, Model mod) {
		String invalid = "Enter correct Details";
		mod.addAttribute("invalid", invalid);
		return "addTrainee";
	}

	@RequestMapping("/")
	public String homePage(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping("/retrieveAll")
	public String retrieveAllTrainee(Model m) {
		List<Trainee> list = null;
		m.addAttribute("list", list);
		return "retrieveAllTrainee";
	}

	@RequestMapping("/delete")
	public String deleteTrainee(Model mod) {
		mod.addAttribute("trainee", new Trainee());
		return "deleteTrainee ";

	}

	@RequestMapping("/modify")
	public String modifyTrainee(Model mod) {
		mod.addAttribute("trainee", new Trainee());
		return "modifyTrainee ";

	}

	@RequestMapping("/retrieve")
	public String retrieveTrainee(Model mod) {
		mod.addAttribute("trainee", new Trainee());
		return "retrieve Trainee";
	}

	
	@RequestMapping(path = "add")
	public String save(@ModelAttribute("trainee") Trainee trainee, Model mod) {

		service.addTrainee(trainee);
		mod.addAttribute("login", new Login());
		return "trainee";
	}

	
	// adding all employee detail
	@RequestMapping("/add")
	public String addtrainee(Model mod) {
		locationList = new ArrayList<String>();

		locationList.add("Pune");
		locationList.add("Mumbai");
		locationList.add("Chennai");
		locationList.add("Bangalore");

		domainList = new ArrayList<String>();

		domainList.add("Java");
		domainList.add("python");
		domainList.add("JDBC");
		domainList.add("SQL");

		mod.addAttribute("domainList", domainList);
		mod.addAttribute("locationList", locationList);

		mod.addAttribute("trainee", new Trainee());

		return "trainee";

	}

}