package com.cg.service;

import com.cg.entity.Trainee;

public interface TraineeInterface {

	void addTrainee(Trainee t);

	public String deleteTrainee(int id);

	Iterable<Trainee> retrieveAll();

	Trainee retrievebyId(int id);

	public Trainee modifyTrainee(Trainee t, int id);

}
